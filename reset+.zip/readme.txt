Reset+ v.3 | Build 24.11.2021

Reset+ (en)
Description: Reset+ is a reasonable combination of reset and modification of CSS 
styles for a web browser necessary for a web developer when creating a website 
of any complexity;
Author: Andrei Ovcharov;
E-mail: datoshcode@gmail.com;
Build date: 24.11.2021;
File name: reset+.css;
License: GNU/GPL.
Complies with the requirements CSS3 and HTML5 !

Provides the ability to download RESET+ in two versions:

The usual version (reset+.css), in which the entire file code is visualized;
Compressed (minimized) version (reset+.min.css), which has the smallest file 
size. 

Also, both versions can be downloaded as an archive (reset+.zip).

I recommend using a compressed version

Example of connecting to a project in the "index.html" file: 
<link rel="stylesheet" href="css/reset+.min.css">

I use it myself and recommend it to you !

--------------------------------------------------

Reset+ (ru)
Описание: Reset+ - разумное сочетание сброса и модификации CSS стилей для 
веб-браузера, необходимое веб-разработчику при создании веб-сайта любой сложности;
Автор: Андрей Овчаров;
E-mail: datoshcode@gmail.com;
Дата сборки: 24.11.2021;
Нименование файла: reset+.css;
Лицензия: GNU/GPL.
Соответствует стандартам CSS3 и HTML5 !

Предоставляется возможность загрузить Reset+ в двух вариантах:

Обычная версия (reset+.css), в которой наглядно виден весь код файла;
Cжатая (минимизированная) версия (reset+.min.css), которая имеет наименьший 
размер файла.

Также, обе версии можно загрузить в качестве архива (reset+.zip).

Рекомендую использовать сжатую версию: reset+.min.css

Пример подключения файла сброса стилей в файле "index.html": 
<link rel="stylesheet" href="css/reset+.min.css">

Рекомендую то, что использую сам !



GitHub repository: (https://github.com/datoshcode/reset_plus_style)