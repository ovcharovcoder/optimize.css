Reset+ v.3 | Build 27.09.2021

Description: Resetting and normalizing browser CSS styles; 
Author: Andrei Ovcharov;
E-mail: datoshcode@gmail.com;
File name: reset+.css
Build date: 27.09.2021;
Example of connecting to a project in the "index.html" file: 
<link rel="stylesheet" href="css/reset+.css">
License: GPL.

GitHub repository: (https://github.com/datoshcode/reset_plus_style)